export interface contact {
  name : string;
  number : number;
}
