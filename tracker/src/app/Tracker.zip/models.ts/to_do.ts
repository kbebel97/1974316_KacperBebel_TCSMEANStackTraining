export class todo{


  constructor(public id : number, public name : string, public task : string, public deadline : string){

  }
}
