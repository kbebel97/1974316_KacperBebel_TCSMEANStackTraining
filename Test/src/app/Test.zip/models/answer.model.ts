export class answer { // this class is use to map json data.

  constructor(public question_id : number , public answer : number){}

}
